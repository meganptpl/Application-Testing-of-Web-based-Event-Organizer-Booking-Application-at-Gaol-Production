package runner;

import org.junit.runner.RunWith;

import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@Cucumber.Options(features="Features_EditProduct", glue="stepDefinition_EditProduct")

public class TestRunner_EditProduct {

}
